/*
  EASY EDIT:
  1) Change the payment details below.
  2) Save this file.
  3) Upload the whole folder to Netlify.
*/
const payments = [
  {name:"bKash", type:"Personal", number:"YOUR_BKASH_NUMBER", owner:"MD SAGOR HOSSEN", icon:"bK", accent:"#e2136e", soft:"#3a1230"},
  {name:"Nagad", type:"Personal", number:"YOUR_NAGAD_NUMBER", owner:"MD SAGOR HOSSEN", icon:"N", accent:"#ff7a18", soft:"#3b2412"},
  {name:"Rocket", type:"Personal", number:"YOUR_ROCKET_NUMBER", owner:"MD SAGOR HOSSEN", icon:"R", accent:"#8b62ff", soft:"#251c45"},
  {name:"Upay", type:"Personal", number:"YOUR_UPAY_NUMBER", owner:"MD SAGOR HOSSEN", icon:"U", accent:"#2d8cff", soft:"#102b4b"},
  {name:"bKash", type:"Personal", number:"YOUR_BKASH_NUMBER_2", owner:"MD SAGOR HOSSEN", icon:"bK", accent:"#e2136e", soft:"#3a1230"},
  {name:"Nagad", type:"Personal", number:"YOUR_NAGAD_NUMBER_2", owner:"MD SAGOR HOSSEN", icon:"N", accent:"#ff7a18", soft:"#3b2412"},
  {name:"CellFin", type:"Personal", number:"YOUR_CELLFIN_NUMBER", owner:"MD SAGOR HOSSEN", icon:"CF", accent:"#27b7a8", soft:"#103934"},
  {name:"mCash", type:"Personal", number:"YOUR_MCash_NUMBER", owner:"MD SAGOR HOSSEN", icon:"mC", accent:"#4b9dff", soft:"#112d4e"}
];

const bank = {
  name:"MD SAGOR HOSSEN",
  number:"YOUR_BANK_ACCOUNT_NUMBER",
  branch:"KALIAKAIR BRANCH"
};

const list = document.getElementById("payment-list");
list.innerHTML = payments.map((p,i)=>`
  <article class="pay-card" style="--accent:${p.accent};--soft:${p.soft}">
    <div class="pay-top">
      <div class="service">
        <div class="service-icon">${p.icon}</div>
        <div><h3>${p.name}</h3><small>${p.type}</small></div>
      </div>
      <span class="badge">PERSONAL</span>
    </div>
    <div class="number">${p.number}</div>
    <div class="owner">● ${p.owner}</div>
    <div class="actions">
      <button class="copy" onclick="copyText('${p.number}')">▣ &nbsp; COPY</button>
      <button class="send" onclick="sendInfo('${p.name}','${p.number}')">➤ &nbsp; SEND MONEY</button>
    </div>
  </article>
`).join("");

document.getElementById("bank-name").textContent = bank.name;
document.getElementById("bank-number").textContent = bank.number;
document.getElementById("bank-branch").textContent = bank.branch;
document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("bank-copy").onclick = () => copyText(bank.number);

async function copyText(text){
  try{
    await navigator.clipboard.writeText(text);
    showToast("নম্বর কপি হয়েছে ✓");
  }catch(e){
    showToast("কপি করা যায়নি");
  }
}

function sendInfo(service, number){
  copyText(number);
  showToast(`${service} নম্বর কপি হয়েছে — পেমেন্ট অ্যাপ থেকে Send Money করুন`);
}

let toastTimer;
function showToast(message){
  const toast=document.getElementById("toast");
  toast.textContent=message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>toast.classList.remove("show"),2500);
}
